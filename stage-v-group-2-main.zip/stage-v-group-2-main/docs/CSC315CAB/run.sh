#! /bin/sh

# start flask
export FLASK_APP=app.py 
flask run

# then browse to http://127.0.0.1:5000/
